package producto_Abstracto;
//Interfaz Abstracta Objetos Concretos
//Producto Abstracto

public interface Vehiculo {
	public String codigoDelVehiculo();
	public int generarCodigoVehiculo();
	public String obtener_info_vehiculo();
}
