package fabrica_Abstracta;
// Fabrica Abstracta

import producto_Abstracto.Vehiculo;

public interface VehiculoDeTransporte {
	public Vehiculo crearVehiculo();
}
 